import java.util.ArrayList;

public class Restaurante implements GerenciamentoProdutos{
    private String nome;
    private String endereco;
    private ArrayList<Produto> produtos;

    public Restaurante(String nome, String endereco) {
        setNome(nome);
        setEndereco(endereco);
        setProdutos(produtos);
    }

    @Override
    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    @Override
    public void removerProduto(String nome) {
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).getNome().trim().equalsIgnoreCase(nome.trim())) {
                produtos.remove(i);
                i--;
            }
        }
    }

    @Override
    public void listarProdutos() {
        for (Produto produto : produtos) System.out.println(produto.detalhar());
    }

    //Getters & Setters
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getEndereco() {
        return endereco;
    }
    public void setEndereco(String endereco) {
        if (endereco != null && !endereco.trim().isEmpty()) this.endereco = endereco;
    }
    
    public ArrayList<Produto> getProdutos() {
        return produtos;
    }
    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = new ArrayList<>();
    }
    
    @Override
    public String toString() {
        return nome + " - " + endereco;
    }
}
