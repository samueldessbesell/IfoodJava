public interface GerenciamentoProdutos {
    void adicionarProduto(Produto p);
    void removerProduto(String nome);
    void listarProdutos();
}
