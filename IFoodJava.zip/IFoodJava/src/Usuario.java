public abstract class Usuario {
    private String nome;
    
    public Usuario(String nome){
        setNome(nome);
    }

    //Getters & Setters
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        if(nome != null && !nome.trim().isEmpty()) this.nome = nome;
    }
}
