public class Bebida extends Produto{
    private int tamanhoMl;
    private boolean alcoolica;

    public Bebida(String nome, String descricao, double preco, int tempoPreparo, int tamanhoMl, boolean alcoolica) {
        super(nome, descricao, preco, tempoPreparo);
        setTamanhoMl(tamanhoMl);
        setAlcool(alcoolica);
    }

    @Override
    public String detalhar() {
        return getNome() + " | R$" + getPreco() + " | " + tamanhoMl + "ml" + " | Alcoólica: " + alcoolica;
    }

    //Getters & Setters
    public int getTamanhoMl() {
        return tamanhoMl;
    }
    public void setTamanhoMl(int tamanhoMl) {
        if (tamanhoMl > 0) this.tamanhoMl = tamanhoMl;
    }

    public boolean isAlcool() {
        return alcoolica;
    }
    public void setAlcool(boolean alcoolica) {
        this.alcoolica = alcoolica;
    }
}
