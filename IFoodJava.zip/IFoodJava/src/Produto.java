public abstract class Produto {
    private String nome;
    private String descricao;
    private double preco;
    private int tempoPreparo;
    
    public Produto(String nome, String descricao, double preco, int tempoPreparo) {
        setNome(nome);
        setDescricao(descricao);
        setPreco(preco);
        setTempoPreparo(tempoPreparo);
    }

    public abstract String detalhar();

    //Getters & Setters
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        if(nome != null && !nome.trim().isEmpty()) this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        if(descricao != null && !descricao.trim().isEmpty()) this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }
    public void setPreco(double preco) {
        if(preco >= 0) this.preco = preco;
    }

    public int getTempoPreparo() {
        return tempoPreparo;
    }
    public void setTempoPreparo(int tempoPreparo) {
        if(tempoPreparo >= 0) this.tempoPreparo = tempoPreparo;
    }
}
